# PrintAccents.py
# coding:  utf-8
 
print "Umlaute:", u"äöü"
print "Accents:", u"àéè"
